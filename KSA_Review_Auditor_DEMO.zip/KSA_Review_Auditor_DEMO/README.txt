KSA Review Auditor Demo

No API key is required. Open public/index.html in a browser. Real Google Maps reviews require a server-side Google Places API integration.
